from sentence_transformers import SentenceTransformer
import os, json
import numpy as np
import faiss
from langchain.text_splitter import RecursiveCharacterTextSplitter

model = SentenceTransformer('all-MiniLM-L6-v2')

def chunk_text(text, chunk_size=300, chunk_overlap=50):
    splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    return splitter.split_text(text)

def generate_embeddings(chunks):
    return model.encode(chunks)

def save_vector_db(embeddings, output_path):
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(embeddings)
    faiss.write_index(index, output_path)

def main():
    with open("data/ebay_user_agreement.txt", "r", encoding='utf-8') as f:
        text = f.read()

    chunks = chunk_text(text)
    os.makedirs("chunks", exist_ok=True)
    json.dump(chunks, open("chunks/chunks.json", "w"))

    embeddings = generate_embeddings(chunks)
    os.makedirs("vectordb", exist_ok=True)
    save_vector_db(np.array(embeddings), "vectordb/faiss_index.index")

if __name__ == '__main__':
    main()