from src.retriever import get_relevant_chunks
from src.generator import generate_answer

def get_streamed_response(query):
    chunks = get_relevant_chunks(query)
    answer = generate_answer(chunks, query)
    yield from answer.split('.')  # stream sentence-by-sentence
