import json, faiss
import numpy as np
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('all-MiniLM-L6-v2')
chunks = json.load(open("chunks/chunks.json"))
index = faiss.read_index("vectordb/faiss_index.index")

def get_relevant_chunks(query, k=4):
    query_emb = model.encode([query])
    D, I = index.search(np.array(query_emb), k)
    return [chunks[i] for i in I[0]]