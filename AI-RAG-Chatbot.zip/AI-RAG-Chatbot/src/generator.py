from transformers import AutoTokenizer, AutoModelForCausalLM
import torch

model_name = "mistralai/Mistral-7B-Instruct-v0.1"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=torch.float16, device_map="auto")

def generate_answer(context_chunks, query):
    prompt = f"""You are a legal assistant trained on the eBay User Agreement.
Use the following context to answer the question.

Context:\n{''.join(context_chunks)}

Question: {query}\nAnswer:"""
    input_ids = tokenizer(prompt, return_tensors="pt").input_ids.cuda()
    output = model.generate(input_ids, max_new_tokens=300, do_sample=True, temperature=0.7)
    return tokenizer.decode(output[0], skip_special_tokens=True).split("Answer:")[-1].strip()