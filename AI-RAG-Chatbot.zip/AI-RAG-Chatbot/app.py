import streamlit as st
from src.rag_pipeline import get_streamed_response

st.set_page_config(page_title="Legal RAG Chatbot")
st.title("📄 Legal Chatbot (RAG-based)")

query = st.text_input("Ask about the eBay User Agreement:")

if query:
    st.markdown("**Answer:**")
    response_placeholder = st.empty()
    output = ""
    for piece in get_streamed_response(query):
        output += piece + "."
        response_placeholder.markdown(output)

    with st.expander("📚 Source Info"):
        st.markdown("Based on retrieved context chunks from the eBay User Agreement.")

st.sidebar.title("🔧 Configuration")
st.sidebar.markdown("**Model:** Mistral-7B-Instruct")
st.sidebar.markdown("**Indexed Chunks:** 100+")

if st.sidebar.button("Clear Chat"):
    st.experimental_rerun()